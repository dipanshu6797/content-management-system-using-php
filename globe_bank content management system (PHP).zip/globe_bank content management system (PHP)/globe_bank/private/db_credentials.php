<?php

define("DB_SERVER", "root");
define("DB_USER", "*****");
define("DB_PASS", "secretpassword");
define("DB_NAME", "globe_bank");

?>
